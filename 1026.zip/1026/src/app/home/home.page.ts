import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  display = "";
  num1 = "";
  operacao = "";
  res = 0;
  auxiliar = "";
  usouPonto = false;
  estaVazio = true;

  constructor() {}

  clicar(numero: string){
    this.display = this.display + numero;

  this.verificarDisplayVazio();
  }
    verificarDisplayVazio(){
    if(this.display.length !== 0){
      this.estaVazio = false;
    }

  }

  usarPonto(){
    if(this.display === ""){
      this.display = this.display + "0";
    }
    this.display = this.display + ".";
    this.usouPonto = true;
  }

  calcular(operacao: string){

    this.usouPonto = false;

    if(this.num1 === "" && this.auxiliar === ""){
      this.num1 = this.display;
      this.display = ""
      this.operacao = operacao;
      this.estaVazio = true;
    }
    else if(operacao === "="){
      if (this.num1 !== ""){
        this.auxiliar = this.display;

      }
      switch(this.operacao){
        case '+': this.somar(); break;
        case '-': this.subtrair(); break;
        case '*': this.multiplicar(); break;
        case '/': this.dividir(); break;
      }
      this.estaVazio = false;
      this.num1 = "";
    }
    else{
      console.log('Já tem um valor na memória: ' + this.num1);
    }
  }

  somar(){
    let n1 = 0;
    let n2 = 0;

    if(this.num1 !== ""){
     n1 = parseFloat(this.num1);
     n2 = parseFloat(this.display);
    }

    else {
      n1 = parseFloat(this.display);
      n2 = parseFloat(this.auxiliar);
    }
    this.res = n1 + n2;
    this.display = this.res.toString();

    this.num1 = n1.toString();
  }

  subtrair(){
    const n1 = parseFloat(this.num1);
    const n2 = parseFloat(this.display);

    this.res = n1 - n2;
    this.display = this.res.toString();


    this.num1 = ;
  }

  multiplicar(){
    const n1 = parseFloat(this.num1);
    const n2 = parseFloat(this.display);

    this.res = n1 * n2;
    this.display = this.res.toString();


    this.num1 = "";
  }

  dividir(){
    const n1 = parseFloat(this.num1);
    const n2 = parseFloat(this.display);

    this.res = n1 / n2;
    this.display = this.res.toString();

    this.num1 = "";
  }


  limpar(){
    this.display = "";
    this.num1 = "";
    this.operacao = "";
    this.res = 0;
    this.usouPonto = false;
    this.estaVazio = true;
  }
}
